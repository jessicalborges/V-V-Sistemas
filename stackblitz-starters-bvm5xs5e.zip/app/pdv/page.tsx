'use client';

import { useState, useEffect } from 'react';
import { supabase } from '../supabase';

export default function PdvPage() {
  const [produtos, setProdutos] = useState<any[]>([]);
  const [clientes, setClientes] = useState<any[]>([]);
  const [carrinho, setCarrinho] = useState<any[]>([]);
  const [buscaPdv, setBuscaPdv] = useState('');
  const [formaPagamento, setFormaPagamento] = useState('PIX');
  const [numParcelas, setNumParcelas] = useState('1');
  const [clienteSelecionadoPdv, setClienteSelecionadoPdv] = useState('');
  const [processando, setProcessando] = useState(false);
  const [comprovante, setComprovante] = useState<any | null>(null);

  useEffect(() => { carregarDados(); }, []);

  const carregarDados = async () => {
    const { data: p } = await supabase.from('produtos').select('*').order('nome');
    if (p) setProdutos(p);
    const { data: c } = await supabase.from('clientes').select('*').order('nome');
    if (c) setClientes(c);
  };

  const obterDataHoraLocalIso = () => {
    const agora = new Date();
    const offsetMs = agora.getTimezoneOffset() * 60000;
    return new Date(agora.getTime() - offsetMs).toISOString().slice(0, 19).replace('T', ' ');
  };

  const formatarDataHoraBr = (dataIso: string) => {
    if (!dataIso) return '-';
    try {
      return new Date(dataIso).toLocaleString('pt-BR', {
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      });
    } catch (e) { return dataIso; }
  };

  const adicionarAoCarrinho = (produto: any) => {
    if (produto.estoque_atual <= 0) return alert('Produto sem estoque!');
    setCarrinho((prev) => {
      const ex = prev.find((i) => i.id === produto.id);
      if (ex) {
        if (ex.qtd >= produto.estoque_atual) return prev;
        return prev.map((i) => (i.id === produto.id ? { ...i, qtd: i.qtd + 1 } : i));
      }
      return [...prev, { ...produto, qtd: 1 }];
    });
  };

  const alterarQtdCarrinho = (id: number, delta: number) => {
    setCarrinho((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const novaQtd = item.qtd + delta;
          return novaQtd > 0 ? { ...item, qtd: novaQtd } : null;
        }
        return item;
      }).filter(Boolean) as any[]
    );
  };

  const totalVenda = carrinho.reduce((acc, i) => acc + i.preco * i.qtd, 0);
  const valorParcela = numParcelas ? totalVenda / Number(numParcelas) : totalVenda;
  const permiteParcelamento = formaPagamento === 'Cartão de Crédito' || formaPagamento === 'Crediário';

  const finalizarVenda = async () => {
    if (carrinho.length === 0) return alert('Carrinho vazio!');
    if (formaPagamento === 'Crediário' && !clienteSelecionadoPdv) {
      return alert('Selecione um cliente para o Crediário!');
    }
    setProcessando(true);

    const clienteObj = clientes.find((c) => c.id === Number(clienteSelecionadoPdv));
    const detalhePag = permiteParcelamento
      ? `${formaPagamento} ${numParcelas}x de R$ ${valorParcela.toFixed(2)}${clienteObj ? ` (Cliente: ${clienteObj.nome})` : ''}`
      : `${formaPagamento}${clienteObj ? ` (Cliente: ${clienteObj.nome})` : ''}`;

    const horaLocal = obterDataHoraLocalIso();

    for (const item of carrinho) {
      const novoEstoque = Math.max(0, item.estoque_atual - item.qtd);
      await supabase.from('produtos').update({ estoque_atual: novoEstoque }).eq('id', item.id);
      await supabase.from('movimentacoes').insert([{
        produto_id: item.id, produto_nome: item.nome, tipo: 'saida',
        quantidade: item.qtd, operador: `Venda - ${detalhePag}`,
        data_movimentacao: horaLocal,
      }]);
    }

    if (formaPagamento === 'Crediário' && clienteObj) {
      await supabase.from('clientes').update({
        saldo_devedor: Number(clienteObj.saldo_devedor) + totalVenda,
      }).eq('id', clienteObj.id);
    }

    setComprovante({
      itens: [...carrinho], total: totalVenda, pagamento: detalhePag,
      clienteNome: clienteObj ? clienteObj.nome : null, data: horaLocal,
    });

    setCarrinho([]);
    setNumParcelas('1');
    setClienteSelecionadoPdv('');
    carregarDados();
    setProcessando(false);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">🛒 Frente de Caixa / PDV Rápido</h2>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <input
            type="text"
            placeholder="🔍 Digite para buscar o produto no caixa..."
            value={buscaPdv}
            onChange={(e) => setBuscaPdv(e.target.value)}
            className="w-full p-3.5 rounded-2xl bg-[#0f172a] border border-slate-800 text-white text-sm"
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[520px] overflow-y-auto">
            {produtos.filter((p) => p.nome.toLowerCase().includes(buscaPdv.toLowerCase())).map((prod) => (
              <div
                key={prod.id}
                onClick={() => adicionarAoCarrinho(prod)}
                className="p-4 rounded-2xl bg-[#0f172a] border border-slate-800 cursor-pointer hover:border-emerald-500 transition-all"
              >
                <div className="flex justify-between items-start mb-1">
                  <h4 className="font-bold text-sm truncate">{prod.nome}</h4>
                  <span className="text-xs font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded">{prod.segmento || 'Geral'}</span>
                </div>
                <div className="text-xs text-slate-400 space-y-0.5">
                  {prod.tamanho && prod.tamanho !== 'N/A' && <p>Tam: <strong className="text-amber-400">{prod.tamanho}</strong></p>}
                  {prod.volume_ml && prod.volume_ml !== 'N/A' && <p>Vol: <strong className="text-emerald-400">{prod.volume_ml}</strong></p>}
                </div>
                <div className="flex justify-between items-end mt-3">
                  <span className="text-xs text-slate-400">Estoque: {prod.estoque_atual} un</span>
                  <span className="text-base font-extrabold text-emerald-400">R$ {Number(prod.preco).toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 rounded-3xl bg-[#0f172a] border border-slate-800 flex flex-col justify-between shadow-xl">
          <div>
            <h3 className="font-bold text-lg mb-4 border-b border-slate-800 pb-3 flex justify-between">
              <span>🛍️ Carrinho</span>
              <span className="text-xs font-normal text-slate-400">({carrinho.length} itens)</span>
            </h3>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {carrinho.map((item) => (
                <div key={item.id} className="flex justify-between items-center text-xs p-2.5 bg-slate-800/40 rounded-xl border border-slate-800">
                  <div>
                    <p className="font-bold truncate">{item.nome}</p>
                    <p className="text-emerald-400">R$ {Number(item.preco).toFixed(2)} un</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => alterarQtdCarrinho(item.id, -1)} className="px-2 py-0.5 bg-slate-700 rounded font-bold">-</button>
                    <span className="font-bold">{item.qtd}</span>
                    <button onClick={() => alterarQtdCarrinho(item.id, 1)} className="px-2 py-0.5 bg-slate-700 rounded font-bold">+</button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 border-t border-slate-800 pt-4">
            <div className="mb-3 bg-indigo-500/10 p-3 rounded-xl border border-indigo-500/30">
              <label className="block text-xs font-bold mb-1 text-indigo-300">👤 Vincular Cliente (Opcional):</label>
              <select
                value={clienteSelecionadoPdv}
                onChange={(e) => setClienteSelecionadoPdv(e.target.value)}
                className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700 text-xs font-bold text-white"
              >
                <option value="">-- Consumidor Não Identificado --</option>
                {clientes.map((c) => (
                  <option key={c.id} value={c.id}>{c.nome} (Débito: R$ {Number(c.saldo_devedor).toFixed(2)})</option>
                ))}
              </select>
            </div>

            <label className="block text-xs font-bold mb-1 text-slate-400">Forma de Pagamento:</label>
            <select
              value={formaPagamento}
              onChange={(e) => setFormaPagamento(e.target.value)}
              className="w-full p-2.5 mb-3 rounded-xl bg-slate-800 border border-slate-700 text-xs font-bold text-white"
            >
              <option value="PIX">⚡ PIX</option>
              <option value="Cartão de Crédito">💳 Cartão de Crédito</option>
              <option value="Cartão de Débito">💳 Cartão de Débito</option>
              <option value="Crediário">📝 Crediário / Carnê (Fiado)</option>
              <option value="Dinheiro">💵 Dinheiro em Espécie</option>
            </select>

            {permiteParcelamento && (
              <div className="mb-4 bg-slate-800/60 p-3 rounded-xl border border-indigo-500/30">
                <label className="block text-xs font-bold mb-1 text-indigo-300">Número de Parcelas ({formaPagamento}):</label>
                <select
                  value={numParcelas}
                  onChange={(e) => setNumParcelas(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700 text-xs font-bold text-amber-400"
                >
                  <option value="1">1x de R$ {(totalVenda / 1).toFixed(2)} (À vista)</option>
                  <option value="2">2x de R$ {(totalVenda / 2).toFixed(2)}</option>
                  <option value="3">3x de R$ {(totalVenda / 3).toFixed(2)}</option>
                  <option value="4">4x de R$ {(totalVenda / 4).toFixed(2)}</option>
                  <option value="5">5x de R$ {(totalVenda / 5).toFixed(2)}</option>
                  <option value="6">6x de R$ {(totalVenda / 6).toFixed(2)}</option>
                </select>
              </div>
            )}

            <div className="flex justify-between items-center mb-4">
              <span className="text-xs text-slate-400 font-bold">TOTAL DA VENDA:</span>
              <span className="text-2xl font-black text-emerald-400">R$ {totalVenda.toFixed(2)}</span>
            </div>

            <button
              onClick={finalizarVenda}
              disabled={carrinho.length === 0 || processando}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-3.5 rounded-2xl font-extrabold text-sm shadow-lg shadow-emerald-600/30 transition-all"
            >
              {processando ? 'Processando...' : '✓ Finalizar Venda & Baixar Estoque'}
            </button>
          </div>
        </div>
      </div>

      {comprovante && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white text-slate-900 p-6 rounded-2xl max-w-sm w-full font-mono text-xs shadow-2xl">
            <div className="text-center border-b pb-3 mb-3 border-dashed border-slate-400">
              <h3 className="font-black text-lg">V&V SISTEMAS</h3>
              <p className="text-[10px] text-slate-500">COMPROVANTE NÃO FISCAL</p>
              <p className="text-[10px] text-slate-500">{formatarDataHoraBr(comprovante.data)}</p>
              {comprovante.clienteNome && <p className="text-[11px] font-bold text-indigo-900 mt-1">Cliente: {comprovante.clienteNome}</p>}
            </div>
            <div className="space-y-1.5 border-b pb-3 mb-3 border-dashed border-slate-400">
              {comprovante.itens.map((item: any, idx: number) => (
                <div key={idx} className="flex justify-between">
                  <span>{item.qtd}x {item.nome}</span>
                  <span className="font-bold">R$ {(item.preco * item.qtd).toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div className="space-y-1 mb-4">
              <div className="flex justify-between font-black text-sm">
                <span>TOTAL:</span>
                <span>R$ {comprovante.total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-600">
                <span>Pagamento:</span>
                <span className="font-semibold">{comprovante.pagamento}</span>
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => window.print()} className="flex-1 bg-indigo-600 text-white font-sans font-bold py-2 rounded-xl">🖨️ Imprimir</button>
              <button onClick={() => setComprovante(null)} className="bg-slate-200 text-slate-700 font-sans font-bold px-4 py-2 rounded-xl">Fechar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}