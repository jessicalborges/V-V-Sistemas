'use client';

import { useState, useEffect } from 'react';
import { supabase } from '../supabase';

export default function EstoquePage() {
  const [produtos, setProdutos] = useState<any[]>([]);
  const [termoBusca, setTermoBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState('todos');
  const [filtroSegmento, setFiltroSegmento] = useState('todos');
  const [editandoId, setEditandoId] = useState<number | null>(null);

  // Formulário Produtos
  const [novoNome, setNovoNome] = useState('');
  const [novoEstoque, setNovoEstoque] = useState('');
  const [novoPrecoCusto, setNovoPrecoCusto] = useState('');
  const [novoPrecoVenda, setNovoPrecoVenda] = useState('');
  const [novoTelefone, setNovoTelefone] = useState('');
  const [novoSegmento, setNovoSegmento] = useState('Geral');
  const [novoGenero, setNovoGenero] = useState('Unissex');
  const [novoTamanho, setNovoTamanho] = useState('M');
  const [novoVolumeMl, setNovoVolumeMl] = useState('100ml');

  // Modal Movimentação Rápida
  const [modalMov, setModalMov] = useState<{
    aberto: boolean;
    produto: any | null;
    tipo: 'entrada' | 'saida';
    qtd: string;
  }>({ aberto: false, produto: null, tipo: 'entrada', qtd: '1' });

  useEffect(() => {
    carregarProdutos();
  }, []);

  const calcularStatusAutomatico = (qtd: number) => {
    if (qtd <= 2) return 'critico';
    if (qtd <= 5) return 'atencao';
    return 'normal';
  };

  const carregarProdutos = async () => {
    const { data } = await supabase.from('produtos').select('*').order('id', { ascending: true });
    if (data) {
      // Atualiza o status dinamicamente com base na quantidade
      const dadosAjustados = data.map((item) => ({
        ...item,
        status: calcularStatusAutomatico(Number(item.estoque_atual) || 0),
      }));
      setProdutos(dadosAjustados);
    }
  };

  const obterDataHoraLocalIso = () => {
    const agora = new Date();
    const offsetMs = agora.getTimezoneOffset() * 60000;
    const dataLocal = new Date(agora.getTime() - offsetMs);
    return dataLocal.toISOString().slice(0, 19).replace('T', ' ');
  };

  const salvarProduto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!novoNome.trim()) return alert('O nome do produto é obrigatório.');

    const qtdEstoqueNum = Number(novoEstoque) || 0;
    const statusCalculado = calcularStatusAutomatico(qtdEstoqueNum);

    const dadosProduto = {
      nome: novoNome,
      estoque_atual: qtdEstoqueNum,
      preco_custo: Number(novoPrecoCusto) || 0,
      preco: Number(novoPrecoVenda) || 0,
      status: statusCalculado,
      telefone_fornecedor: novoTelefone,
      segmento: novoSegmento,
      genero: novoGenero,
      tamanho: novoSegmento === 'Roupas' ? novoTamanho : 'N/A',
      volume_ml: novoSegmento === 'Perfumaria' ? novoVolumeMl : 'N/A',
    };

    if (editandoId) {
      const { error } = await supabase
        .from('produtos')
        .update(dadosProduto)
        .eq('id', editandoId);

      if (error) {
        alert('Erro ao atualizar produto: ' + error.message);
        return;
      }

      setProdutos((prev) =>
        prev.map((p) => (p.id === editandoId ? { ...p, ...dadosProduto } : p))
      );
    } else {
      const { data, error } = await supabase
        .from('produtos')
        .insert([dadosProduto])
        .select();

      if (error) {
        alert('Erro ao cadastrar produto: ' + error.message);
        return;
      }

      if (data && data[0]) {
        setProdutos((prev) => [...prev, { ...data[0], status: statusCalculado }]);
      }
    }

    limparFormulario();
    await carregarProdutos();
  };

  const editarProduto = (produto: any) => {
    setEditandoId(produto.id);
    setNovoNome(produto.nome || '');
    setNovoEstoque(produto.estoque_atual !== undefined ? String(produto.estoque_atual) : '0');
    setNovoPrecoCusto(produto.preco_custo !== undefined ? String(produto.preco_custo) : '0');
    setNovoPrecoVenda(produto.preco !== undefined ? String(produto.preco) : '0');
    setNovoTelefone(produto.telefone_fornecedor || '');
    setNovoSegmento(produto.segmento || 'Geral');
    setNovoGenero(produto.genero || 'Unissex');
    setNovoTamanho(produto.tamanho || 'M');
    setNovoVolumeMl(produto.volume_ml || '100ml');

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const deletarProduto = async (id: number) => {
    if (confirm('Deseja realmente excluir este produto?')) {
      await supabase.from('produtos').delete().eq('id', id);
      setProdutos((prev) => prev.filter((p) => p.id !== id));
      carregarProdutos();
    }
  };

  const limparFormulario = () => {
    setNovoNome('');
    setNovoEstoque('');
    setNovoPrecoCusto('');
    setNovoPrecoVenda('');
    setNovoTelefone('');
    setNovoSegmento('Geral');
    setNovoGenero('Unissex');
    setNovoTamanho('M');
    setNovoVolumeMl('100ml');
    setEditandoId(null);
  };

  const confirmarMovimentacao = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalMov.produto || !modalMov.qtd) return;

    const qtdNum = Math.abs(Number(modalMov.qtd)) || 0;
    if (qtdNum <= 0) return;

    const produto = modalMov.produto;
    const novoEstoqueCalc =
      modalMov.tipo === 'entrada'
        ? produto.estoque_atual + qtdNum
        : Math.max(0, produto.estoque_atual - qtdNum);

    const statusAtualizado = calcularStatusAutomatico(novoEstoqueCalc);

    await supabase
      .from('produtos')
      .update({
        estoque_atual: novoEstoqueCalc,
        status: statusAtualizado,
      })
      .eq('id', produto.id);

    await supabase.from('movimentacoes').insert([
      {
        produto_id: produto.id,
        produto_nome: produto.nome,
        tipo: modalMov.tipo,
        quantidade: qtdNum,
        operador: 'Ajuste Manual Estoque',
        data_movimentacao: obterDataHoraLocalIso(),
      },
    ]);

    setProdutos((prev) =>
      prev.map((p) =>
        p.id === produto.id
          ? { ...p, estoque_atual: novoEstoqueCalc, status: statusAtualizado }
          : p
      )
    );

    setModalMov({ aberto: false, produto: null, tipo: 'entrada', qtd: '1' });
    carregarProdutos();
  };

  const enviarWhatsApp = async (produtoNome: string, telefone: string) => {
    await supabase.from('pedidos_reposicao').insert([
      {
        produto_nome: produtoNome,
        solicitante: 'Operador',
        data_pedido: obterDataHoraLocalIso(),
      },
    ]);

    const num = telefone.replace(/\D/g, '') || '5548999999999';
    const msg = encodeURIComponent(
      `Olá! Preciso fazer a reposição urgente do produto: ${produtoNome}.`
    );
    window.open(`https://wa.me/${num}?text=${msg}`, '_blank');
  };

  const exportarExcel = () => {
    if (produtos.length === 0) return alert('Nenhum produto cadastrado para exportar.');

    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'ID;Nome;Segmento;Genero;Tamanho;Volume;Estoque;Preco Custo;Preco Venda;Status\n';

    produtos.forEach((p) => {
      csvContent += `${p.id};"${p.nome}";"${p.segmento || 'Geral'}";"${p.genero || ''}";"${
        p.tamanho || ''
      }";"${p.volume_ml || ''}";${p.estoque_atual};${p.preco_custo || 0};${
        p.preco || 0
      };"${p.status}"\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `inventario_vevsistemas_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const produtosFiltrados = produtos.filter((p) => {
    const combinaNome = p.nome.toLowerCase().includes(termoBusca.toLowerCase());
    const combinaStatus = filtroStatus === 'todos' || p.status === filtroStatus;
    const combinaSegmento = filtroSegmento === 'todos' || p.segmento === filtroSegmento;
    return combinaNome && combinaStatus && combinaSegmento;
  });

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Gerenciamento de Inventário 📦</h2>
        <button
          onClick={exportarExcel}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2"
        >
          📊 Exportar Excel (.CSV)
        </button>
      </div>

      <form
        onSubmit={salvarProduto}
        className="p-5 rounded-2xl mb-8 border border-slate-800 bg-[#0f172a] shadow-md"
      >
        <h3 className="text-base font-bold mb-4 text-indigo-400">
          {editandoId ? `✏️ Editando Produto ID #${editandoId}` : '➕ Novo Produto'}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
          <div className="md:col-span-2">
            <label className="block text-xs font-bold mb-1 text-slate-400">Nome do Produto:</label>
            <input
              type="text"
              placeholder="Ex: Camiseta Básica Preta"
              value={novoNome}
              onChange={(e) => setNovoNome(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold mb-1 text-slate-400">Segmento:</label>
            <select
              value={novoSegmento}
              onChange={(e) => setNovoSegmento(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-indigo-400 text-sm font-bold"
            >
              <option value="Geral">📦 Geral</option>
              <option value="Roupas">👕 Roupas / Moda</option>
              <option value="Perfumaria">🧴 Perfumaria / Beleza</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold mb-1 text-slate-400">Estoque Atual (Qtd):</label>
            <input
              type="number"
              placeholder="Ex: 10"
              value={novoEstoque}
              onChange={(e) => setNovoEstoque(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-bold mb-1 text-slate-400">Preço de Custo (R$):</label>
            <input
              type="number"
              step="0.01"
              placeholder="0.00"
              value={novoPrecoCusto}
              onChange={(e) => setNovoPrecoCusto(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-bold mb-1 text-slate-400">Preço de Venda (R$):</label>
            <input
              type="number"
              step="0.01"
              placeholder="0.00"
              value={novoPrecoVenda}
              onChange={(e) => setNovoPrecoVenda(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-bold mb-1 text-slate-400">Gênero:</label>
            <select
              value={novoGenero}
              onChange={(e) => setNovoGenero(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm"
            >
              <option value="Unissex">Unissex</option>
              <option value="Feminino">Feminino</option>
              <option value="Masculino">Masculino</option>
              <option value="Infantil">Infantil</option>
            </select>
          </div>

          {novoSegmento === 'Roupas' && (
            <div>
              <label className="block text-xs font-bold mb-1 text-slate-400">Tamanho:</label>
              <select
                value={novoTamanho}
                onChange={(e) => setNovoTamanho(e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-amber-400 text-sm"
              >
                <option value="PP">PP</option>
                <option value="P">P</option>
                <option value="M">M</option>
                <option value="G">G</option>
                <option value="GG">GG</option>
                <option value="XGG">XGG</option>
                <option value="36">36</option>
                <option value="38">38</option>
                <option value="40">40</option>
                <option value="42">42</option>
                <option value="44">44</option>
              </select>
            </div>
          )}

          {novoSegmento === 'Perfumaria' && (
            <div>
              <label className="block text-xs font-bold mb-1 text-slate-400">Volume (ml):</label>
              <input
                type="text"
                placeholder="Ex: 100ml"
                value={novoVolumeMl}
                onChange={(e) => setNovoVolumeMl(e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-emerald-400 text-sm"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-bold mb-1 text-slate-400">WhatsApp Fornecedor:</label>
            <input
              type="text"
              placeholder="Ex: 48999999999"
              value={novoTelefone}
              onChange={(e) => setNovoTelefone(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm"
            />
          </div>
        </div>

        <div className="flex gap-3 mt-2">
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold transition-all text-sm"
          >
            {editandoId ? 'Atualizar Produto' : 'Cadastrar Produto'}
          </button>
          {editandoId && (
            <button
              type="button"
              onClick={limparFormulario}
              className="bg-slate-600 hover:bg-slate-700 text-white px-5 py-2.5 rounded-xl font-bold transition-all text-sm"
            >
              Cancelar Edição
            </button>
          )}
        </div>
      </form>

      <div className="rounded-2xl border border-slate-800 bg-[#0f172a] overflow-hidden shadow-md">
        <div className="p-4 border-b border-slate-800 flex flex-wrap justify-between items-center gap-3">
          <input
            type="text"
            placeholder="🔍 Buscar produto por nome..."
            value={termoBusca}
            onChange={(e) => setTermoBusca(e.target.value)}
            className="p-2.5 px-4 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm w-64"
          />

          <select
            value={filtroSegmento}
            onChange={(e) => setFiltroSegmento(e.target.value)}
            className="p-2.5 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm font-semibold"
          >
            <option value="todos">Todos os Segmentos</option>
            <option value="Geral">📦 Geral</option>
            <option value="Roupas">👕 Roupas</option>
            <option value="Perfumaria">🧴 Perfumaria</option>
          </select>

          <select
            value={filtroStatus}
            onChange={(e) => setFiltroStatus(e.target.value)}
            className="p-2.5 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm font-semibold"
          >
            <option value="todos">Todos os Status</option>
            <option value="critico">🚨 Críticos (≤ 2 un)</option>
            <option value="atencao">⚠️ Atenção (3-5 un)</option>
            <option value="normal">✅ Normais (≥ 6 un)</option>
          </select>
        </div>

        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-800/40 text-xs font-bold text-slate-400 uppercase tracking-wider">
              <th className="p-4">Produto / Detalhes</th>
              <th className="p-4">Estoque</th>
              <th className="p-4">Custo / Venda</th>
              <th className="p-4">Margem</th>
              <th className="p-4 text-center">Ações Rápidas</th>
            </tr>
          </thead>
          <tbody>
            {produtosFiltrados.map((item) => {
              const custo = Number(item.preco_custo) || 0;
              const venda = Number(item.preco) || 0;
              const margem = venda - custo;
              const statusCalculado = calcularStatusAutomatico(Number(item.estoque_atual) || 0);

              return (
                <tr key={item.id} className="border-b border-slate-800 hover:bg-slate-800/20 transition-colors">
                  <td className="p-4">
                    <p className="font-bold text-sm">{item.nome}</p>
                    <div className="flex gap-2 text-xs text-slate-400 mt-0.5 items-center">
                      <span className="bg-slate-800 px-2 py-0.5 rounded text-indigo-300 font-semibold">
                        {item.segmento || 'Geral'}
                      </span>
                      {item.genero && item.genero !== 'N/A' && <span>• {item.genero}</span>}
                      {item.tamanho && item.tamanho !== 'N/A' && (
                        <span className="text-amber-400 font-bold">• Tam: {item.tamanho}</span>
                      )}
                      {item.volume_ml && item.volume_ml !== 'N/A' && (
                        <span className="text-emerald-400 font-bold">• {item.volume_ml}</span>
                      )}
                      <span className={`px-2 py-0.5 rounded font-black uppercase text-[10px] ${
                        statusCalculado === 'critico' ? 'bg-red-500/20 text-red-400 border border-red-500/40' :
                        statusCalculado === 'atencao' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' :
                        'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      }`}>
                        {statusCalculado === 'critico' ? '🚨 CRÍTICO' : statusCalculado === 'atencao' ? '⚠️ ATENÇÃO' : '✅ NORMAL'}
                      </span>
                    </div>
                  </td>

                  <td className="p-4 font-bold text-sm">{item.estoque_atual} un</td>

                  <td className="p-4 text-xs">
                    <p className="text-slate-400">Custo: R$ {custo.toFixed(2)}</p>
                    <p className="font-bold text-sm text-white">Venda: R$ {venda.toFixed(2)}</p>
                  </td>

                  <td className="p-4 font-bold text-xs text-emerald-400">+ R$ {margem.toFixed(2)}</td>

                  <td className="p-4 text-center">
                    <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                      <button
                        onClick={() =>
                          setModalMov({
                            aberto: true,
                            produto: item,
                            tipo: 'entrada',
                            qtd: '1',
                          })
                        }
                        className="px-2.5 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-black shadow-sm transition-all"
                        title="Registrar Entrada"
                      >
                        + Entrada
                      </button>

                      <button
                        onClick={() =>
                          setModalMov({
                            aberto: true,
                            produto: item,
                            tipo: 'saida',
                            qtd: '1',
                          })
                        }
                        className="px-2.5 py-1.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-black shadow-sm transition-all"
                        title="Registrar Saída"
                      >
                        - Saída
                      </button>

                      <button
                        onClick={() => enviarWhatsApp(item.nome, item.telefone_fornecedor)}
                        className="px-2.5 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
                        title="Pedir Reposição via WhatsApp"
                      >
                        💬 Pedir
                      </button>

                      <button
                        onClick={() => editarProduto(item)}
                        className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
                        title="Editar Produto"
                      >
                        ✏️ Editar
                      </button>

                      <button
                        onClick={() => deletarProduto(item.id)}
                        className="p-1.5 px-2 bg-slate-700 hover:bg-rose-600 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-all"
                        title="Excluir Produto"
                      >
                        🗑️
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* MODAL ENTRADA / SAÍDA RÁPIDA */}
      {modalMov.aberto && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-sm p-6 rounded-2xl border border-slate-800 bg-[#0f172a] text-white shadow-2xl">
            <h3 className="text-lg font-bold mb-3">🔄 Lançar Movimentação</h3>

            <form onSubmit={confirmarMovimentacao}>
              <label className="block text-xs font-bold mb-1">Tipo de Operação:</label>
              <select
                value={modalMov.tipo}
                onChange={(e) =>
                  setModalMov({
                    ...modalMov,
                    tipo: e.target.value as 'entrada' | 'saida',
                  })
                }
                className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm mb-3"
              >
                <option value="entrada">⬇️ Entrada no Estoque</option>
                <option value="saida">⬆️ Saída do Estoque</option>
              </select>

              <label className="block text-xs font-bold mb-1">Produto Selecionado:</label>
              <input
                type="text"
                value={modalMov.produto?.nome || ''}
                disabled
                className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-900 text-slate-400 text-sm mb-3 font-bold"
              />

              <label className="block text-xs font-bold mb-1">Quantidade de Unidades:</label>
              <input
                type="number"
                min="1"
                value={modalMov.qtd}
                onChange={(e) => setModalMov({ ...modalMov, qtd: e.target.value })}
                className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-800 text-white text-sm mb-4"
                required
              />

              <div className="flex gap-2">
                <button
                  type="submit"
                  className={`flex-1 py-2.5 rounded-xl font-bold text-xs text-white transition-all ${
                    modalMov.tipo === 'entrada'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-red-600 hover:bg-red-700'
                  }`}
                >
                  Confirmar {modalMov.tipo === 'entrada' ? 'Entrada' : 'Saída'}
                </button>
                <button
                  type="button"
                  onClick={() => setModalMov({ aberto: false, produto: null, tipo: 'entrada', qtd: '1' })}
                  className="px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}