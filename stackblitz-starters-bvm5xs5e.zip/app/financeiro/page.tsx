'use client';

import { useState, useEffect } from 'react';
import { supabase } from '../supabase';

export default function FinanceiroPage() {
  const [movimentacoes, setMovimentacoes] = useState<any[]>([]);
  const [dataInicio, setDataInicio] = useState('');
  const [dataFim, setDataFim] = useState('');

  useEffect(() => {
    supabase.from('movimentacoes').select('*').order('id', { ascending: false }).then(({ data }) => {
      if (data) setMovimentacoes(data);
    });
  }, []);

  const formatarDataHoraBr = (dataIso: string) => {
    if (!dataIso) return '-';
    try {
      return new Date(dataIso).toLocaleString('pt-BR', {
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      });
    } catch (e) { return dataIso; }
  };

  const vendasFiltradas = movimentacoes.filter((m) => {
    if (m.tipo !== 'saida' || !m.operador?.includes('Venda')) return false;
    if (!dataInicio && !dataFim) return true;
    const dataMov = m.data_movimentacao.slice(0, 10);
    const i = dataInicio || '1970-01-01';
    const f = dataFim || '2099-12-31';
    return dataMov >= i && dataMov <= f;
  });

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold flex items-center gap-2">📈 Relatórios Financeiros</h2>
        <button onClick={() => window.print()} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md">🖨️ Imprimir Relatório</button>
      </div>

      <div className="p-5 bg-[#0f172a] border border-slate-800 rounded-2xl mb-6 shadow-sm">
        <h3 className="text-xs font-bold mb-3 text-indigo-400">📅 Filtrar Faturamento por Período</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
          <div>
            <label className="block text-xs font-bold mb-1 text-slate-400">Data Inicial:</label>
            <input type="date" value={dataInicio} onChange={(e) => setDataInicio(e.target.value)} className="w-full p-2.5 bg-slate-800 border border-slate-700 text-xs font-bold text-white rounded-xl" />
          </div>
          <div>
            <label className="block text-xs font-bold mb-1 text-slate-400">Data Final:</label>
            <input type="date" value={dataFim} onChange={(e) => setDataFim(e.target.value)} className="w-full p-2.5 bg-slate-800 border border-slate-700 text-xs font-bold text-white rounded-xl" />
          </div>
          <div>
            <button onClick={() => { setDataInicio(''); setDataFim(''); }} className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold py-2.5 rounded-xl text-xs">🧹 Limpar Filtros</button>
          </div>
        </div>
      </div>

      <div className="bg-[#0f172a] border border-slate-800 rounded-2xl overflow-hidden shadow-md">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-xs font-bold">🛒 Histórico de Vendas Faturadas</h3>
          <span className="text-xs text-slate-400">{dataInicio || dataFim ? 'Exibindo período filtrado' : 'Exibindo todo o histórico'}</span>
        </div>
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-800/40 text-slate-400 font-bold uppercase border-b border-slate-800">
            <tr>
              <th className="p-4">Produto</th>
              <th className="p-4">Qtd Vendida</th>
              <th className="p-4">Detalhes da Operação / Cliente</th>
              <th className="p-4 text-right">Data e Hora</th>
            </tr>
          </thead>
          <tbody>
            {vendasFiltradas.map((m) => (
              <tr key={m.id} className="border-b border-slate-800">
                <td className="p-4 font-bold">{m.produto_nome}</td>
                <td className="p-4 font-black text-amber-400">{m.quantidade} un</td>
                <td className="p-4 text-indigo-300">{m.operador}</td>
                <td className="p-4 text-right text-slate-400">🕒 {formatarDataHoraBr(m.data_movimentacao)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}