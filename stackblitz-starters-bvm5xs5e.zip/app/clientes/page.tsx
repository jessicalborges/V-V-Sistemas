'use client';

import { useState, useEffect } from 'react';
import { supabase } from '../supabase';

export default function ClientesPage() {
  const [clientes, setClientes] = useState<any[]>([]);
  const [exibirForm, setExibirForm] = useState(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [nome, setNome] = useState('');
  const [cpf, setCpf] = useState('');
  const [telefone, setTelefone] = useState('');
  const [endereco, setEndereco] = useState('');
  const [limite, setLimite] = useState('');
  const [busca, setBusca] = useState('');

  useEffect(() => { carregarClientes(); }, []);

  const carregarClientes = async () => {
    const { data } = await supabase.from('clientes').select('*').order('nome');
    if (data) setClientes(data);
  };

  const converterMoedaParaNumero = (valor: string | number): number => {
    if (!valor) return 0;
    if (typeof valor === 'number') return valor;
    return Number(valor.replace(/\./g, '').replace(',', '.')) || 0;
  };

  const salvarCliente = async (e: React.FormEvent) => {
    e.preventDefault();
    const dados = {
      nome, cpf_cnpj: cpf, telefone, endereco,
      limite_credito: converterMoedaParaNumero(limite),
    };

    if (editandoId) {
      await supabase.from('clientes').update(dados).eq('id', editandoId);
    } else {
      await supabase.from('clientes').insert([{ ...dados, saldo_devedor: 0 }]);
    }

    limpar();
    carregarClientes();
  };

  const editar = (c: any) => {
    setEditandoId(c.id); setNome(c.nome); setCpf(c.cpf_cnpj || '');
    setTelefone(c.telefone || ''); setEndereco(c.endereco || '');
    setLimite(Number(c.limite_credito || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
    setExibirForm(true);
  };

  const deletarCliente = async (id: number) => {
    if (confirm('Deseja excluir este cliente?')) {
      await supabase.from('clientes').delete().eq('id', id);
      carregarClientes();
    }
  };

  const limpar = () => {
    setNome(''); setCpf(''); setTelefone(''); setEndereco(''); setLimite('');
    setEditandoId(null); setExibirForm(false);
  };

  const quitar = async (c: any) => {
    const val = prompt(`Valor a quitar de ${c.nome} (Débito: R$ ${Number(c.saldo_devedor).toFixed(2)}):`, c.saldo_devedor.toString());
    if (!val) return;
    const pag = converterMoedaParaNumero(val);
    if (pag <= 0) return;

    await supabase.from('clientes').update({ saldo_devedor: Math.max(0, Number(c.saldo_devedor) - pag) }).eq('id', c.id);
    carregarClientes();
  };

  const totalReceberCrediario = clientes.reduce((acc, item) => acc + (Number(item.saldo_devedor) || 0), 0);

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold flex items-center gap-2">👥 Clientes & Crediário</h2>
        <button
          onClick={() => (exibirForm ? limpar() : setExibirForm(true))}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-md"
        >
          {exibirForm ? '✖️ Fechar' : '➕ Criar Cliente'}
        </button>
      </div>

      {exibirForm && (
        <form onSubmit={salvarCliente} className="p-5 bg-[#0f172a] border border-slate-800 rounded-2xl mb-6 grid grid-cols-1 md:grid-cols-3 gap-3">
          <input type="text" placeholder="Nome Completo" value={nome} onChange={(e) => setNome(e.target.value)} className="p-3 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white" required />
          <input type="text" placeholder="CPF / CNPJ" value={cpf} onChange={(e) => setCpf(e.target.value)} className="p-3 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white" />
          <input type="text" placeholder="WhatsApp / Telefone" value={telefone} onChange={(e) => setTelefone(e.target.value)} className="p-3 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white" />
          <input type="text" placeholder="Endereço Completo" value={endereco} onChange={(e) => setEndereco(e.target.value)} className="p-3 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white md:col-span-2" />
          <input type="text" placeholder="Limite de Crédito (ex: 5.000,00)" value={limite} onChange={(e) => setLimite(e.target.value)} className="p-3 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white" />
          <div className="flex gap-2 md:col-span-3 mt-2">
            <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs">
              {editandoId ? 'Atualizar Cliente' : 'Salvar Cliente'}
            </button>
          </div>
        </form>
      )}

      <div className="bg-[#0f172a] border border-slate-800 rounded-2xl overflow-hidden shadow-md">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center">
          <input type="text" placeholder="🔍 Buscar por nome ou CPF..." value={busca} onChange={(e) => setBusca(e.target.value)} className="p-2.5 px-4 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white w-72" />
          <span className="text-xs font-bold text-amber-400">
            Total a Receber: R$ {totalReceberCrediario.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </span>
        </div>
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-800/40 text-xs font-bold text-slate-400 uppercase">
              <th className="p-4">Cliente</th>
              <th className="p-4">Contato / Endereço</th>
              <th className="p-4">Limite Crédito</th>
              <th className="p-4">Saldo Devedor</th>
              <th className="p-4 text-center">Ações</th>
            </tr>
          </thead>
          <tbody>
            {clientes.filter((c) => c.nome.toLowerCase().includes(busca.toLowerCase())).map((c) => (
              <tr key={c.id} className="border-b border-slate-800 text-xs">
                <td className="p-4"><p className="font-bold">{c.nome}</p><p className="text-slate-400 text-[10px]">{c.cpf_cnpj}</p></td>
                <td className="p-4"><p className="text-indigo-400">{c.telefone}</p><p className="text-slate-400 truncate max-w-[200px]">{c.endereco}</p></td>
                <td className="p-4 font-semibold">R$ {Number(c.limite_credito || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                <td className="p-4 font-black text-red-400">R$ {Number(c.saldo_devedor || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                <td className="p-4 text-center">
                  <div className="flex justify-center gap-1.5">
                    {Number(c.saldo_devedor) > 0 && (
                      <button onClick={() => quitar(c)} className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold">💵 Quitar</button>
                    )}
                    <button onClick={() => editar(c)} className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-bold">✏️ Editar</button>
                    <button onClick={() => deletarCliente(c.id)} className="p-1.5 px-2 bg-slate-700 hover:bg-rose-600 text-slate-300 hover:text-white rounded-lg font-bold">🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}