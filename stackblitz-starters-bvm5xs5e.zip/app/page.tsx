'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { supabase } from './supabase';

export default function Home() {
  const [produtos, setProdutos] = useState<any[]>([]);
  const [clientes, setClientes] = useState<any[]>([]);

  useEffect(() => {
    supabase.from('produtos').select('*').then(({ data }) => { if (data) setProdutos(data); });
    supabase.from('clientes').select('*').then(({ data }) => { if (data) setClientes(data); });
  }, []);

  // Conta a quantidade de PRODUTOS distintos em estado crítico
  const produtosCriticosCount = produtos.filter(
    (p) => Number(p.estoque_atual) <= 2
  ).length;

  const totalReceberCrediario = clientes.reduce((acc, item) => acc + (Number(item.saldo_devedor) || 0), 0);
  const valorTotalCusto = produtos.reduce((acc, item) => acc + (Number(item.estoque_atual) || 0) * (Number(item.preco_custo) || 0), 0);
  const valorTotalVenda = produtos.reduce((acc, item) => acc + (Number(item.estoque_atual) || 0) * (Number(item.preco) || 0), 0);
  const lucroEstimadoTotal = valorTotalVenda - valorTotalCusto;

  return (
    <div className="max-w-5xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
        Visão Geral do Estoque 📊
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="p-4 rounded-2xl border-l-4 border-l-red-500 border border-slate-800 bg-[#0f172a] shadow-md">
          <p className="text-xs font-bold text-slate-400 uppercase">Produtos Críticos</p>
          <div className="flex items-baseline gap-1.5 mt-2">
            <span className="text-3xl font-extrabold text-red-500">{produtosCriticosCount}</span>
            <span className="text-xs font-bold text-slate-400">itens</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl border-l-4 border-l-amber-500 border border-slate-800 bg-[#0f172a] shadow-md">
          <p className="text-xs font-bold text-slate-400 uppercase">A Receber (Crediário)</p>
          <p className="text-2xl font-extrabold text-amber-400 mt-2">
            R$ {totalReceberCrediario.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </p>
        </div>

        <div className="p-4 rounded-2xl border-l-4 border-l-blue-500 border border-slate-800 bg-[#0f172a] shadow-md">
          <p className="text-xs font-bold text-slate-400 uppercase">Custo Investido</p>
          <p className="text-2xl font-extrabold text-blue-400 mt-2">
            R$ {valorTotalCusto.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </p>
        </div>

        <div className="p-4 rounded-2xl border-l-4 border-l-emerald-500 border border-slate-800 bg-[#0f172a] shadow-md">
          <p className="text-xs font-bold text-slate-400 uppercase">Lucro Estimado</p>
          <p className="text-2xl font-extrabold text-emerald-400 mt-2">
            R$ {lucroEstimadoTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link href="/pdv" className="p-6 bg-[#0f172a] border border-slate-800 hover:border-emerald-500 rounded-2xl transition-all">
          <span className="text-3xl block mb-2">🛒</span>
          <h3 className="font-bold text-lg text-emerald-400">Frente de Caixa (PDV)</h3>
          <p className="text-xs text-slate-400 mt-1">Realizar vendas rápidas, emitir cupons e dar baixa de estoque.</p>
        </Link>

        <Link href="/clientes" className="p-6 bg-[#0f172a] border border-slate-800 hover:border-indigo-500 rounded-2xl transition-all">
          <span className="text-3xl block mb-2">👥</span>
          <h3 className="font-bold text-lg text-indigo-400">Clientes & Crediário</h3>
          <p className="text-xs text-slate-400 mt-1">Cadastrar clientes, gerenciar carnês e quitar dívidas de fiado.</p>
        </Link>

        <Link href="/estoque" className="p-6 bg-[#0f172a] border border-slate-800 hover:border-blue-500 rounded-2xl transition-all">
          <span className="text-3xl block mb-2">📦</span>
          <h3 className="font-bold text-lg text-blue-400">Inventário de Produtos</h3>
          <p className="text-xs text-slate-400 mt-1">Cadastrar novos itens, custos, fornecedores e atualizar estoque.</p>
        </Link>
      </div>
    </div>
  );
}