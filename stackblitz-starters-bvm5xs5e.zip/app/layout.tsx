'use client';

import { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import { supabase } from './supabase';
import './globals.css';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<any>(null);
  const [darkMode, setDarkMode] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => setSession(session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => setSession(session));
    return () => subscription.unsubscribe();
  }, []);

  const nomeUsuario = session?.user?.email ? session.user.email.split('@')[0] : 'Operador';

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setSession(null);
  };

  return (
    <html lang="pt-BR">
      <body className={darkMode ? 'bg-[#0b0f19] text-white' : 'bg-slate-100 text-slate-900'}>
        <div className="flex min-h-screen font-sans">
          {session && (
            <Sidebar
              darkMode={darkMode}
              setDarkMode={setDarkMode}
              nomeUsuario={nomeUsuario}
              handleLogout={handleLogout}
            />
          )}
          <main className="flex-1 p-8 relative">{children}</main>
        </div>
      </body>
    </html>
  );
}